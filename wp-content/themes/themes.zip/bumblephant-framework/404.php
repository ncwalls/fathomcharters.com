<?php
wp_redirect( home_url(), 301 );
exit();